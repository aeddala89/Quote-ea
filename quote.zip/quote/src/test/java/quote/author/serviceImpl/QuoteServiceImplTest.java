package quote.author.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import quote.author.exception.ProductNotFoundException;
import quote.author.service.QuoteService;

@SpringBootTest
public class QuoteServiceImplTest {
	
	@Autowired
	QuoteService quoteService;
	
	
	@Test
	public void getRandomQuoteTest() {
		quoteService.getRandomQuote();
		assertNotNull(quoteService);
	}
	
	@Test
	public void getQuotesTest() {
		quoteService.getQuotes();
		assertNotNull(quoteService);
	}
	
	@Test
	public void getIdTest() {
		quoteService.getId("2");
		assertNotNull(quoteService);
	}
	
	@Test()
	public void getIdTest1() {
		
		 assertThrows(ProductNotFoundException.class, () -> {
			 quoteService.getId("ffgrt"); // Assuming this ID does not exist
	        });
	}
	

}

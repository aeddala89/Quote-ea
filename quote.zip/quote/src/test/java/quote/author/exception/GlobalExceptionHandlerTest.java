package quote.author.exception;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class GlobalExceptionHandlerTest {
	
	@Autowired
	GlobalExceptionHandler exceptionHandler;
	
	
	@Test
	public void handleExceptionTest() {
		
		exceptionHandler.handleException(new Exception());
		exceptionHandler.handleProductNotFoundException(new ProductNotFoundException("invalid"));
		
	}

}

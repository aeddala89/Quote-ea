package quote.author.model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class QuoteResponseTest {
	
	
	@Test
	public void quoteResponseTest() {
		
		QuoteResponse quoteResponse = new QuoteResponse();
		Quotes quotes =  new  Quotes();
		quotes.setAuthor("dgdfert");
		quotes.setId("123");
		quotes.setQuote("hi");
		quoteResponse.setId("123");
		quoteResponse.setAuthor("amul");
		quoteResponse.setQuote("hi");
		quoteResponse.getAuthor();
		quoteResponse.getId();
		quoteResponse.getQuote();
		quoteResponse.getQuotes();	
	}

}

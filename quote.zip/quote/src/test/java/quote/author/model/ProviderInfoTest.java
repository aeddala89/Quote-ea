package quote.author.model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProviderInfoTest {
	

	
	@Test
	public void providerInfoTest() {
		
		ProviderInfo info = new ProviderInfo();
		
		info.setDescription("not fund");
		info.setErrorCode("400");
		info.setType("error");
		info.getDescription();
		info.getErrorCode();
		info.getType();

	}

}

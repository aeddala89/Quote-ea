package quote.author;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@RunWith(SpringRunner.class)
@SpringBootTest
class QuoteApplicationTests {

	@Test
	void contextLoads() {
	}

}

package quote.author.service;

import quote.author.model.QuoteResponse;
import quote.author.model.Quotes;

public interface QuoteService {
	
	public QuoteResponse getRandomQuote();

	public QuoteResponse getQuotes();

	public Quotes getId(String id); 

}

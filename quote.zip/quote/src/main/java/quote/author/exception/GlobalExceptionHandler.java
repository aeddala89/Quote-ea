package quote.author.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import quote.author.model.ProviderInfo;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<ProviderInfo> handleException(Exception e) {
		
		ProviderInfo info = new ProviderInfo();
		info.setErrorCode("500");
		info.setType("error");
		info.setDescription("An unexpected error occurred");
        return new ResponseEntity<ProviderInfo>(info, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	 @ExceptionHandler(ProductNotFoundException.class)
	    @ResponseStatus(HttpStatus.NOT_FOUND)
	    public ResponseEntity<ProviderInfo> handleProductNotFoundException(ProductNotFoundException e) {
		 
			ProviderInfo info = new ProviderInfo();
			info.setDescription("Id Not Found");
			info.setErrorCode("404");
			info.setType("error");

	        return new ResponseEntity<ProviderInfo>(info, HttpStatus.NOT_FOUND);
	    }
	
}

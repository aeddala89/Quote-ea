package quote.author.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class QuoteResponse {
	
	
	
	private String id;
	private String quote;
	private String author;
	
	public List<Quotes> getQuotes() {
		return quotes;
	}
	public void setQuotes(List<Quotes> quotes) {
		this.quotes = quotes;
	}

	private List<Quotes> quotes;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQuote() {
		return quote;
	}
	public void setQuote(String quote) {
		this.quote = quote;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	@Override
	public String toString() {
		return "QuoteResponse [id=" + id + ", quote=" + quote + ", author=" + author + "]";
	}

}

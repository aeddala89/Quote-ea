package quote.author.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import quote.author.model.QuoteResponse;
import quote.author.model.Quotes;
import quote.author.service.QuoteService;

@RestController
@RequestMapping("/api")
public class QuoteController {

	@Autowired
	QuoteService quoteService;

	@GetMapping("/random")
	public ResponseEntity<QuoteResponse> getRandomQuote() {

		return new ResponseEntity<QuoteResponse>(quoteService.getRandomQuote(),HttpStatus.OK);
		
	}
	@GetMapping("/quotes")
	public ResponseEntity<QuoteResponse> getQuotes(HttpServletRequest request, HttpServletResponse response){
		
		return new ResponseEntity<QuoteResponse>(quoteService.getQuotes(),HttpStatus.OK) ;
	}
	
	@GetMapping("/getId")
	public ResponseEntity<Quotes> getId(HttpServletRequest request, HttpServletResponse response, @RequestHeader(value="id") String id){
		
		return new ResponseEntity<Quotes>(quoteService.getId(id),HttpStatus.OK) ;
	}

}

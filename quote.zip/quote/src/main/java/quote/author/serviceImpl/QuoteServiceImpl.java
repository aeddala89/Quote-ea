package quote.author.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import quote.author.exception.ProductNotFoundException;
import quote.author.model.QuoteResponse;
import quote.author.model.Quotes;
import quote.author.service.QuoteService;

@Service
public class QuoteServiceImpl implements QuoteService {
	
	@Autowired
	RestTemplate restTemplate;
	
    @Value("${quote.random.uri}")
	private String urlRandom;
	
    @Value("${quote.quotes.uri}")
	private String urlQuotes;
	
	    
	    public QuoteResponse getRandomQuote() {
	    	
	        return restTemplate.getForObject(urlRandom, QuoteResponse.class);
	    }
			
			public QuoteResponse getQuotes() {
								
		        String urlQuotes = "https://dummyjson.com/quotes";
		        QuoteResponse response = restTemplate.getForObject(urlQuotes, QuoteResponse.class);

		        return response;
		    }

			@Override
			public Quotes getId(String id) {
								
				 String urlQuotes = "https://dummyjson.com/quotes";
			        QuoteResponse response = restTemplate.getForObject(urlQuotes, QuoteResponse.class);
			       Optional<Quotes> quotes=  response.getQuotes().stream().filter(s->s.getId().equalsIgnoreCase(id)).findAny();
			      if (quotes.isPresent()) 
			    	  return quotes.get();
				throw new ProductNotFoundException("product not found");   	  
			    
			}
			
		}

